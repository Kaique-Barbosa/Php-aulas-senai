<?php
include 'conection.php';


$nome = $_POST['nome'];
$escolaridade = $_POST['escolaridade'];
$serie = $_POST['serie'];

$sql = "INSERT INTO estudantes (`nome`, `escolaridade`, `serie`)  VALUES('$nome', '$escolaridade','$serie')";
if(isset($nome) && isset($escolaridade) && isset($serie)){
    if($resultado = $mysqli->query($sql)){
        echo ("<script>alert('Parabens Inserção concluida')</script>");
        header('location: ./index.php');
    } else{
        echo ("<script>alert('Erro ao inserir no banco')</script>");
        header('location: ./index.php');
    }

}
$mysqli -> close();
?>