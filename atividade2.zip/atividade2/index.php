<?php
include 'select.php';

$num = 0;
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Atividade 2</title>
</head>

<body>
    <form action="crud.php" method="post">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Nome</label>
            <input type="text" name="nome" placeholder="Digite seu nome" class="form-control" id="exampleInputEmail1"
                aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="escolaridade">Escolaridade</label>
            <select class="form-select" name="escolaridade" aria-label="Default select example" id="escolaridade">
                <option selected disabled>Selecione seua escolaridade</option>
                <option value="Ensino Fundamental">Ensino Fundamental</option>
                <option value="Ensino médio">Ensino médio</option>
                <option value="Ensino Superior">Ensino Superior</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="Serie">Serie</label>
            <select class="form-select" name="serie" aria-label="Default select example" id="Serie">
                <option selected disabled>Selecione seua Serie</option>
                <option value="1">1º</option>
                <option value="2">2º</option>
                <option value="3">3º</option>
            </select>
        </div>
        <div class="mb-3">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">nome</th>
                        <th scope="col">Escolaridade</th>
                        <th scope="col">Serie</th>
                        <th scope="col">deletar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    
                    if ($result->num_rows > 0) {
                        // Loop através dos resultados e criar as opções do select
                        while ($row = $result->fetch_assoc()) {
                            $id = $row['id'];
                            $nome = $row['nome'];
                            $escolaridade = $row['escolaridade'];
                            $serie = $row['serie'];
                        
                            echo(
                                "
                                  <tr>
                                <th scope='row'>$id</th>
                                <td>$nome</td>
                                <td>$escolaridade</td>
                                <td>$serie</td>
                                <td><button type='button' id='btnExcluir' class='btn btn-danger'>Excluir</button></td>
                                </tr>
                                "
                            );
                        }
                    } else {
                        echo "Nenhum resultado encontrado.";
                    }
                         
                        
                  
                    // <tr>
                    //     <th scope="row">3</th>
                    //     <td colspan="2">Larry the Bird</td>
                    //     <td>@twitter</td>
                    // </tr>
                    ?>
                </tbody>
            </table>
        </div>

        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>