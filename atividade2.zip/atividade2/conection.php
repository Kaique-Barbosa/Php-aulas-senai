<?php

$mysqli = new mysqli('localhost', 'root', '', 'colegio');

if($mysqli->connect_error){
   echo "Desconectado! Erro: " . $mysqli->connect_error;
}

?>