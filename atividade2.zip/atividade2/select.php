<?php
include 'conection.php';

$sql = "SELECT * FROM estudantes";

$result = $mysqli -> query($sql);

?>