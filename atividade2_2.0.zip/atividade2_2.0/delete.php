<?php
include 'conection.php';
$id = $_POST['idExclusao'];

$sql = "DELETE FROM `colegio`.`estudantes` WHERE (`id` = '$id');";

if($mysqli->query($sql)){
    echo "<script>alert('Deletado com sucesso')</script>";
}
header('location: ./index.php');
?>