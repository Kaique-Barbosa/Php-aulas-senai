<?php

$mysqli = new mysqli('localhost', 'root', '', 'colegio');

   $criarTabela= 
   "  CREATE TABLE  IF NOT EXISTS estudantes(
       id INT AUTO_INCREMENT,
       nome VARCHAR(200) NOT NULL,
       escolaridade VARCHAR(200) NOT NULL,
       serie INT NOT NULL,
       PRIMARY KEY(id)
       );";

if(!$mysqli -> query($criarTabela) == TRUE){
   echo "Erro ao criar o banco e tabela". $mysqli->error;
} 
  


if($mysqli->connect_error){
   echo "Desconectado! Erro: " . $mysqli->connect_error;
} 

?>